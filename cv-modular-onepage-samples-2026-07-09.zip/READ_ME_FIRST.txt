Saul Karim Nassau modular CV output samples
Release: 2026-07-16 FINAL6 deploy-contract repair

This archive contains the current designed PDFs, ATS-safe PDFs, plain-text outputs, complete career archive, modular one-page state audits, browser interaction audit, and deploy-contract repair record.
The website source retains the canonical record at data/saul-cv-canonical-2026.json. No copy is placed in public/data.
