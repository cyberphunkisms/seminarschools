Every current role-focused CV output generated from the canonical 2026 modular data. Education is the only version carrying the MA postnominal.
